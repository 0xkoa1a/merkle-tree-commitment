#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merkle Tree 性能与安全测试（精简版）

用法：python3 test2.py
"""

import itertools
import math
import os
import platform
import random
import sys
import time


HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import merkle_tree as m

SIZES = [8, 32, 64, 128, 256, 512, 1024]


def fmt_time(s):
    if s < 1e-3:
        return f"{s * 1e6:.1f} us"
    if s < 1:
        return f"{s * 1e3:.3f} ms"
    return f"{s:.3f} s"


def timeit(fn, *args, target=0.15, max_calls=200):
    calls, t0 = 0, time.perf_counter()
    while True:
        fn(*args)
        calls += 1
        if time.perf_counter() - t0 >= target or calls >= max_calls:
            return (time.perf_counter() - t0) / calls


def show(title, headers, rows, note=""):
    print(f"\n== {title} ==")
    widths = [max(len(str(r[i])) for r in [headers] + rows) for i in range(len(headers))]
    print("  ".join(str(h).ljust(widths[i]) for i, h in enumerate(headers)))
    for r in rows:
        print("  ".join(str(c).ljust(widths[i]) for i, c in enumerate(r)))
    if note:
        print(note)


def height_of(root):
    h, node = 0, root
    while node.left:
        node, h = node.left, h + 1
    return h


def proof_lengths(leaf_map):
    return [len(m.get_sibling_path(v, leaf_map)) for v in leaf_map]


def test_build():
    rows = []
    for n in SIZES:
        leaves = [f"leaf-{i}" for i in range(n)]
        t = timeit(m.buildTree, leaves, target=0.15, max_calls=20)
        root, _ = m.buildTree(leaves)
        rows.append([n, height_of(root), 2 * n - 1, fmt_time(t), fmt_time(t / n),
                     f"{n / t:.0f}"])
    show("1. 建树性能随叶子数变化",
         ["n", "height", "hashes", "build time", "per leaf", "leaves/s"],
         rows, "建树耗时随 n 线性增长，哈希次数 ≈ 2n-1。")


def test_proof():
    rng = random.Random(0)
    rows = []
    for n in SIZES:
        leaves = [f"leaf-{i}" for i in range(n)]
        root, leaf_map = m.buildTree(leaves)
        idx = sorted(set([0, n // 2, n - 1] + rng.sample(range(n), min(2, n))))
        gen = ver = 0.0
        ok = 0
        for i in idx:
            v = leaves[i]
            gen += timeit(m.get_sibling_path, v, leaf_map, target=0.03)
            path = m.get_sibling_path(v, leaf_map)
            ver += timeit(m.verify_path, v, path, target=0.03)
            ok += (m.verify_path(v, path) == root.hashValue)
        lens = proof_lengths(leaf_map)
        rows.append([n, height_of(root), fmt_time(gen / len(idx)), fmt_time(ver / len(idx)),
                     f"{sum(lens) / len(lens) * 32:.0f} B", f"{ok}/{len(idx)}"])
    show("2. Proof 生成 / 验证随叶子数变化",
         ["n", "height", "proof gen", "proof verify", "proof size", "verified"],
         rows, "证明长度与验证代价均为 O(log n)，生成只沿指针遍历。")


def test_security(n=256):
    leaves = [f"leaf-{i}" for i in range(n)]
    root, leaf_map = m.buildTree(leaves)
    real = root.hashValue
    path0 = m.get_sibling_path(leaves[0], leaf_map)

    all_ok = all(m.verify_path(v, m.get_sibling_path(v, leaf_map)) == real for v in leaves)
    forge = m.verify_path("not-in-tree", path0) == real

    bad_hash = [dict(s) for s in path0]
    bad_hash[0]["sibling_hash"] = m.sha3_256(b"forged")
    tamper_hash = m.verify_path(leaves[0], bad_hash) == real

    bad_side = [dict(s) for s in path0]
    bad_side[0]["sibling_side"] = "left" if bad_side[0]["sibling_side"] == "right" else "right"
    tamper_side = m.verify_path(leaves[0], bad_side) == real

    shuffled = leaves[:]
    random.Random(1).shuffle(shuffled)
    deterministic = m.buildTree(leaves)[0].hashValue == real
    order_sensitive = m.buildTree(shuffled)[0].hashValue != real

    single_root, single_map = m.buildTree(["only"])
    single_ok = m.verify_path("only", m.get_sibling_path("only", single_map)) == single_root.hashValue

    rows = [
        ["all proofs verify", "PASS" if all_ok else "FAIL"],
        ["forge non-member value", "REJECT" if not forge else "ACCEPT!"],
        ["tamper sibling hash", "REJECT" if not tamper_hash else "ACCEPT!"],
        ["flip sibling side", "REJECT" if not tamper_side else "ACCEPT!"],
        ["deterministic root", "PASS" if deterministic else "FAIL"],
        ["order sensitivity", "PASS" if order_sensitive else "FAIL"],
        ["single leaf", "PASS" if single_ok else "FAIL"],
    ]
    show(f"3. 正确性与安全（n={n}）", ["case", "result"], rows,
         "全量证明通过；伪造与篡改均被拒绝；根确定且对叶子顺序敏感。")


def test_odd_leaves():
    rows = []
    for n in (3, 5, 7, 9):
        leaves = [f"leaf-{i}" for i in range(n)]
        root, leaf_map = m.buildTree(leaves)
        lens = proof_lengths(leaf_map)
        ok = sum(1 for v in leaves
                 if m.verify_path(v, m.get_sibling_path(v, leaf_map)) == root.hashValue)
        rows.append([n, f"{min(lens)}/{max(lens)}", f"{ok}/{n}"])
    show("4. 奇数叶子", ["n", "path len min/max", "verified"], rows,
         "奇数层末节点被上提，不同叶子路径长度不齐。")


def _candidate_root(hashes):
    while len(hashes) > 1:
        hashes = [m.sha3_256(hashes[i] + hashes[i + 1]) if i + 1 < len(hashes) else hashes[i]
                  for i in range(0, len(hashes), 2)]
    return hashes[0]


def test_low_entropy():
    alphabet, k = "0123456789", 3
    secret = random.Random(0).sample(alphabet, k)
    target = m.buildTree(secret)[0].hashValue           # 树在构建时已加全局盐

    t0, tried, found = time.perf_counter(), 0, "not found"
    for combo in itertools.permutations(alphabet, k):   # 攻击者不知道 SALT，按无盐枚举
        tried += 1
        if _candidate_root([m.sha3_256(c) for c in combo]) == target:
            found = "".join(combo)
            break
    dt = time.perf_counter() - t0

    show("5. 低熵叶子枚举（树已加盐）",
         ["candidates", "tried", "time", "result"],
         [[math.perm(len(alphabet), k), tried, fmt_time(dt), found]],
         "攻击者不知道 SALT，枚举无法重建根 => hiding 受保护。")


def main():
    print("Merkle Tree 性能与安全测试（精简版）")
    print(f"Python {platform.python_version()} / {platform.system()} {platform.machine()}")
    test_build()
    test_proof()
    test_security()
    test_odd_leaves()
    test_low_entropy()


if __name__ == "__main__":
    main()
