#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用手动 SHA3-256 构建的二叉 Merkle Tree。

提供：buildTree / get_sibling_path / verify_path，以及全局盐 SALT。
哈希原语来自 sha3.py。
"""

from sha3 import sha3_256


# ============================================================
# 全局盐（Salt）：叶子哈希 = SHA3-256(SALT + value)
# ============================================================
# SALT 是全局变量，可按需自行修改；构建与验证必须使用同一个 SALT。
# 默认值仅供演示，实际使用请改成随机且保密的盐。
SALT = b"merkle-tree-salt"


def leaf_hash(value) -> str:
    """叶子哈希：SHA3-256(SALT + value)，SALT 为全局盐。"""
    if isinstance(value, str):
        value = value.encode("utf-8")
    return sha3_256(SALT + value)


# ============================================================
# Merkle Tree
# ============================================================

class MerkleTreeNode:
    def __init__(self, value, is_hash=False):
        self.left = None
        self.right = None
        self.parent = None
        self.value = value
        # is_hash=True 表示传入的 value 已经是哈希值（内部节点）
        if is_hash:
            self.hashValue = value
        else:
            # 叶子哈希加盐：H(SALT || value)；内部节点不加盐
            self.hashValue = leaf_hash(value)


def buildTree(leaves):
    nodes = [MerkleTreeNode(leaf) for leaf in leaves]
    leaf_map = {node.value: node for node in nodes}

    while len(nodes) > 1:
        temp = []
        for i in range(0, len(nodes), 2):
            node1 = nodes[i]
            if i + 1 < len(nodes):
                node2 = nodes[i + 1]
            else:
                temp.append(node1)
                break

            # 父节点的哈希 = SHA3(left_hash + right_hash)
            concatenated = node1.hashValue + node2.hashValue
            parent = MerkleTreeNode(sha3_256(concatenated), is_hash=True)
            parent.left = node1
            parent.right = node2
            node1.parent = parent
            node2.parent = parent
            temp.append(parent)

        nodes = temp

    return nodes[0], leaf_map


def get_sibling_path(value, leaf_map):
    """返回从 value 对应叶子到根的兄弟节点路径"""
    if value not in leaf_map:
        raise ValueError(f"value '{value}' 不在 Merkle 树中")

    node = leaf_map[value]
    path = []

    while node.parent is not None:
        parent = node.parent
        if parent.left is node:
            sibling = parent.right
            side = 'right'
        else:
            sibling = parent.left
            side = 'left'

        path.append({
            'node_hash': node.hashValue,
            'sibling_hash': sibling.hashValue if sibling else None,
            'sibling_side': side,
            'parent_hash': parent.hashValue,
        })
        node = parent

    return path


def verify_path(value, sibling_path):
    """用兄弟路径重算根哈希，验证 value 是否在树中"""
    # 与 buildTree 保持一致：从「加盐后的叶子哈希」出发
    current = leaf_hash(value)
    for step in sibling_path:
        sibling = step['sibling_hash']
        if step['sibling_side'] == 'right':
            current = sha3_256(current + sibling)
        else:
            current = sha3_256(sibling + current)
    return current


# ============================================================
# 测试
# ============================================================
if __name__ == '__main__':
    leaves = ['a', 'b', 'c', 'd']
    root, leaf_map = buildTree(leaves)
    print("=== Merkle Tree ===")
    print("Root Hash:", root.hashValue)

    print("\n=== 'a' 的兄弟路径 ===")
    path_a = get_sibling_path('a', leaf_map)
    for item in path_a:
        print(item)

    recomputed = verify_path('a', path_a)
    print("\nRecomputed root:", recomputed)
    print("Match:", recomputed == root.hashValue)
